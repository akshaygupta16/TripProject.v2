package com.example.tripprojectv2;

public interface IJoinButton {
    void joinButtonPressed();
}
